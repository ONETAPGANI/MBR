import React, { useState } from 'react';
import { Search, ShoppingCart, Menu, User, Heart, Bell } from 'lucide-react';
import Navbar from './components/Navbar';
import ProductCard from './components/ProductCard';
import Footer from './components/Footer';
import { products } from './data/products';

function App() {
  const [cartCount] = useState(0);

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar cartCount={cartCount} />
      
      {/* Hero Section */}
      <div className="relative h-[500px] bg-cover bg-center" style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1469334031218-e382a71b716b?ixlib=rb-1.2.1&auto=format&fit=crop&w=2000&q=80")'
      }}>
        <div className="absolute inset-0 bg-black bg-opacity-40 flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-5xl font-bold mb-4">MBR FASHION HUB</h1>
            <p className="text-xl mb-8">Discover Your Style, Define Your Fashion</p>
            <button className="bg-white text-black px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition">
              Shop Now
            </button>
          </div>
        </div>
      </div>

      {/* Categories */}
      <div className="container mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold mb-8">Shop by Category</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
          {['Women', 'Men', 'Accessories', 'Shoes'].map((category) => (
            <div key={category} className="relative rounded-lg overflow-hidden group cursor-pointer">
              <img 
                src={`https://images.unsplash.com/photo-${category === 'Women' ? '1483985988355-763728e1935b' : 
                category === 'Men' ? '1490578474895-699cd4e2cf59' : 
                category === 'Accessories' ? '1512163143273-bde0e3cc7939' : 
                '1460353581641-37baddab0fa2'}?auto=format&fit=crop&w=500&q=60`} 
                alt={category}
                className="w-full h-48 object-cover group-hover:scale-105 transition duration-300"
              />
              <div className="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center">
                <h3 className="text-white text-xl font-bold">{category}</h3>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Featured Products */}
      <div className="container mx-auto px-4 py-12">
        <h2 className="text-2xl font-bold mb-8">Featured Products</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </div>

      <Footer />
    </div>
  );
}

export default App;